from __future__ import print_function
import json
import io
import boto3
from  PyPDF2 import PdfFileReader
import time
import urllib
print('Loading function')

s3 = boto3.resource('s3')


def get_info(path):
    with open(path, 'rb') as f:
        pdf = PdfFileReader(f)
        info = pdf.getDocumentInfo()
        number_of_pages = pdf.getNumPages()
    print(info)
    print(number_of_pages)


def F(event, context):
    print("starting function")
    bucket = event['Records'][0]['s3']['bucket']['name']
    for record in event['Records']:
        key = urllib.parse.unquote_plus(record['s3']['object']['key'])
        try:
          print("Bucket: "+ bucket)
          print("Key: "+ key)
          obj = s3.Object(bucket_name=bucket, key=key)
        except Exception as e:
          print(e)
          print('Error getting object {} from bucket {}. Make sure they exist '
                'and your bucket is in the same region as this '
                'function.'.format(key, bucket))
          raise e
        response = obj.get()
        body = response['Body']
        print("write body")
        try:
          with io.FileIO('/tmp/temp.pdf', 'w') as file:
            for b in body._raw_stream:
                file.write(b)
            
        except Exception as e:
            print(e)
            print('Error getting object {} from bucket {}. Make sure they exist '
                  'and your bucket is in the same region as this '
                  'function.'.format(key, bucket))
        raise e
        print("get info")
        get_info('/tmp/temp.pdf')
   
